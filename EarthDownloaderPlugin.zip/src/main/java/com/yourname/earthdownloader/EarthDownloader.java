// EarthDownloader.java � full plugin source code
// (Copy the code I gave earlier and paste it here)